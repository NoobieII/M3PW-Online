//Lithio
//February 27, 2022

//constants

#ifndef CONSTANTS_HPP
#define CONSTANTS_HPP

const int kScreenWidth  = 640;
const int kScreenHeight = 480;
const int kFrameRate = 30;
const int kTileSize = 64;

#endif
